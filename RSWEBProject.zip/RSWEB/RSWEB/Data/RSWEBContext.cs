﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using RSWEB.Areas.Identity.Data;
using RSWEB.Models;

namespace RSWEB.Data
{
    public class RSWEBContext : IdentityDbContext<RSWEBUser>
    {
        public RSWEBContext (DbContextOptions<RSWEBContext> options)
            : base(options)
        {
        }

        public DbSet<RSWEB.Models.Course>? Course { get; set; }

        public DbSet<RSWEB.Models.Enrollment>? Enrollment { get; set; }

        public DbSet<RWSEB.Models.Student>? Student { get; set; }

        public DbSet<RSWEB.Models.Teacher>? Teacher { get; set; }
        protected override void OnModelCreating(ModelBuilder builder)
        {
           base.OnModelCreating(builder);
        }
    }
}
    

