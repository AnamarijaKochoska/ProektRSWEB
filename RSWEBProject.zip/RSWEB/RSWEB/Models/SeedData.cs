﻿using RSWEB.Data;
using RSWEB.Areas.Identity.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RSWEB.Models;
using RWSEB.Models;

namespace RSWEB.Models
{
    public class SeedData
    {
        public static async Task CreateUserRoles(IServiceProvider serviceProvider)
        {
            var RoleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var UserManager = serviceProvider.GetRequiredService<UserManager<RSWEBUser>>();
            IdentityResult roleResult;
            //Add Admin Role
            var roleCheck = await RoleManager.RoleExistsAsync("Admin");
            if (!roleCheck) { roleResult = await RoleManager.CreateAsync(new IdentityRole("Admin")); }
            RSWEBUser user = await UserManager.FindByEmailAsync("admin@uni.com");
            if (user == null)
            {
                var User = new RSWEBUser();
                User.Email = "admin@uni.com";
                User.UserName = "admin@uni.com";
                string userPWD = "Admin123";
                IdentityResult chkUser = await UserManager.CreateAsync(User, userPWD);
                //Add default User to Role Admin
                if (chkUser.Succeeded) { var result1 = await UserManager.AddToRoleAsync(User, "Admin"); }
            }

            var roleCheck1 = await RoleManager.RoleExistsAsync("Professor");
            if (!roleCheck1) { roleResult = await RoleManager.CreateAsync(new IdentityRole("Professor")); }
            RSWEBUser user1 = await UserManager.FindByEmailAsync("professor@uni.com");
            if (user1 == null)
            {
                var User = new RSWEBUser();
                User.Email = "professor@uni.com";
                User.UserName = "professor@uni.com";
                string userPWD = "Professor123";
                IdentityResult chkUser = await UserManager.CreateAsync(User, userPWD);
                //Add default User to Role Admin
                if (chkUser.Succeeded) { var result1 = await UserManager.AddToRoleAsync(User, "Professor"); }
            }

            var roleCheck2 = await RoleManager.RoleExistsAsync("Student");
            if (!roleCheck2) { roleResult = await RoleManager.CreateAsync(new IdentityRole("Student")); }
            RSWEBUser user2 = await UserManager.FindByEmailAsync("student@uni.com");
            if (user2 == null)
            {
                var User = new RSWEBUser();
                User.Email = "student@uni.com";
                User.UserName = "student@uni.com";
                string userPWD = "Student123";
                IdentityResult chkUser = await UserManager.CreateAsync(User, userPWD);
                //Add default User to Role Admin
                if (chkUser.Succeeded) { var result1 = await UserManager.AddToRoleAsync(User, "Student"); }
            }
        }

        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new RSWEBContext(
            serviceProvider.GetRequiredService<
            DbContextOptions<RSWEBContext>>()))
            {
                if (context.Course.Any() || context.Student.Any() || context.Teacher.Any())
                {
                    return; // DB has been seeded
                }
                context.Teacher.AddRange(
                new Teacher { /*Id = 1, */FirstName = "Bjanka", LastName = "Nasteska", Degree = "FEIT", AcademicRank = "Doktor" },
                new Teacher { /*Id = 2, */FirstName = "Dimitrij", LastName = "Gjorgovski", Degree = "PMF", AcademicRank = "Docent" },
                new Teacher { /*Id = 3, */FirstName = "Dea", LastName = "Paunovic", Degree = "FINKI", AcademicRank = "Magister" }
                );
                context.SaveChanges();
                context.Student.AddRange(
          new Student { /*Id = 1, */FirstName = "Emanuela", LastName = "Gjerasimoska", AcquiredCredits = 50 },
          new Student { /*Id = 2, */FirstName = "Konstantin", LastName = "Kosteski", AcquiredCredits = 45 },
          new Student { /*Id = 3, */FirstName = "David", LastName = "Zdraveski", AcquiredCredits = 45 },
          new Student { /*Id = 4, */FirstName = "Aleksandra", LastName = "Srbinoska", AcquiredCredits = 45 },
          new Student { /*Id = 5, */FirstName = "Evangelija", LastName = "Vasileska", AcquiredCredits = 45 },
          new Student { /*Id = 6, */FirstName = "Simona", LastName = "Korunoska", AcquiredCredits = 45 },
          new Student { /*Id = 7, */FirstName = "Ivo", LastName = "Jovanoski", AcquiredCredits = 45 },
          new Student { /*Id = 8, */FirstName = "Mile", LastName = "Atanasovski", AcquiredCredits = 45 }
          );
                context.SaveChanges();

                context.Course.AddRange(
    new Course
    {
        //Id = 1,
        Title = "Physics 2",
        Credits = 6,
        Semester = 3,
        Programme = "KTI",
        FirstTeacherId = context.Teacher.Single(d => d.FirstName == "Dea" && d.LastName == "Paunovic").TeacherId,

    },
new Course
{
    //Id = 2,
    Title = "Mathematics 1",
    Credits = 8,
    Semester = 6,
    Programme = "KSIAR",
    FirstTeacherId = context.Teacher.Single(d => d.FirstName == "Bjanka" && d.LastName == "Nasteska").TeacherId,
    SecondTeacherId = context.Teacher.Single(d => d.FirstName == "Dimitrij" && d.LastName == "Gjorgovski").TeacherId
},
new Course
{
    //Id = 3,
    Title = "Computer Networks",
    Credits = 4,
    Semester = 5,
    Programme = "KTI",
    FirstTeacherId = context.Teacher.Single(d => d.FirstName == "Dimitrij" && d.LastName == "Gjorgovski").TeacherId,

}
);
                context.SaveChanges();
                context.Enrollment.AddRange(

                         new Enrollment
                         {
                             StudentId = context.Student.Single(d => d.FirstName == "Emanuela" && d.LastName == "Gjerasimoska").StudentId,
                             CourseId = context.Course.Single(d => d.Title == "Mathematics 1").CourseId
                         },
                          new Enrollment
                          {
                              StudentId = context.Student.Single(d => d.FirstName == "Mile" && d.LastName == "Atanasovski").StudentId,
                              CourseId = context.Course.Single(d => d.Title == "Computer Networks").CourseId
                          },
                           new Enrollment
                           {
                               StudentId = context.Student.Single(d => d.FirstName == "Aleksandra" && d.LastName == "Srbinoska").StudentId,
                               CourseId = context.Course.Single(d => d.Title == "Physics 2").CourseId
                           },
                          new Enrollment
                            {
                                StudentId = context.Student.Single(d => d.FirstName == "Simona" && d.LastName == "Korunoska").StudentId,
                                CourseId = context.Course.Single(d => d.Title == "Computer Networks").CourseId,
                            },
                             new Enrollment
                             {
                                 StudentId = context.Student.Single(d => d.FirstName == "Evangelija" && d.LastName == "Vasileska").StudentId,
                                 CourseId = context.Course.Single(d => d.Title == "Mathematics 1").CourseId,
                             }
                         );
                context.SaveChanges();
            }
        }
    }
}